package com.company;

//public class Main {


import java.util.LinkedList;
import java.util.ListIterator;
import java.util.Scanner;
        public class Main {
            public static  void main(String[] args) throws InterruptedException {
                Scanner in=new Scanner(System.in);
                System.out.println("Create  the  Playlist--");
                System.out.println("Please Enter your Playlist Name");
                String playlistname=in.nextLine();
                LinkedList songs=new LinkedList();
                boolean first=true;
                while(first){
                    System.out.println("\nEnter 1) To Add Songs To Main: "+playlistname+"\n"+ "Enter 2)To Delete Songs From Playlist: "+playlistname+"\n"+ "Enter 3) To show the songs in Playlist: "+playlistname+"\n"+ "Enter 4) To Play The Playlist: "+playlistname+"\n"+
                    "Enter 5) To Exit");
                    int choice1=in.nextInt();

                    switch(choice1){
                        case 1:
                            System.out.print("Enter The name of the Song: ");
                            in.nextLine();
                            String songName=in.nextLine();
                            System.out.print("Enter The Name of the artist: ");
                            String artist=in.nextLine();
                            System.out.print("Enter The Duration of the song: ");
                            String duration=in.nextLine();
                            song s= (song) new song( songName, artist,duration);
                            songs.add(s);
                            System.out.println(songName + " song is added to playlist "+playlistname+ "!!!\n");
                            break;
                        case 2:
                            if(songs.size()==0){
                                System.out.println("No songs present in the Playlist: "+playlistname);
                                break;
                            }
                            else{
                                System.out.println("Here is the List of songs");
                                for(Object i:songs){
                                    i.wait();
                                }
                                System.out.println("Enter The index of the song to remove,first song is at index 1");
                                int index=in.nextInt();
                                if(index<=0|| index>songs.size())
                                {
                                    System.out.println("No Song in that index");
                                }
                                else{
                                    songs.remove(index-1);

                                    System.out.println("Song Removed!!");
                                }
                                break;
                            }
                        case 3:
                            if(songs.size()==0){
                                System.out.println("No songs in the playlist");
                            }
                            else{
                                System.out.println("Here is the List of songs");
                                for(Object i:songs){
                                   i.wait();
                                }
                            }
                            break;
                        case 4:
                            if(songs.size()==0){
                                System.out.println("No songs in the playlist");
                                break;
                            }
                            else{
                                System.out.println("Here is the List of songs");
                                for(Object i:songs){
                                   i.wait();
                                }
                                System.out.println("Current Song-----");
                               songs.getFirst().wait();
                                ListIterator<song> j=songs.listIterator();
                                j.next();
                                boolean forward=true;
                                boolean finished=false;
                                boolean second=true;
                                while(second){
                                    System.out.println("\n Enter 1)To play the next song\n" + "Enter 2)To play the previous song\n" +"Enter 3)To play the same song again\n" +"Enter 4)To stop the playlist");
                                    int choice2=in.nextInt();
                                    switch(choice2){
                                        case 1:
                                            if(!forward)
                                            {
                                                if(j.hasNext())
                                                {
                                                    j.next();
                                                }
                                                forward=true;
                                            }
                                            if(finished==true){
                                                j.previous();
                                                finished=false;
                                            }
                                            if(j.hasNext())
                                            {
                                                System.out.println("Song Playing----->");
                                               j.next().showSong();
                                            }
                                            else{
                                                System.out.println("Playlist finished.....");
                                                finished=true;
                                            }
                                            break;
                                        case 2:
                                            if(forward)
                                            {
                                                if(j.hasPrevious())
                                                {
                                                    j.previous();
                                                }
                                                forward=false;
                                            }
                                            if(finished==true){
                                                j.next();
                                                finished=false;
                                            }
                                            if(j.hasPrevious())
                                            {
                                                System.out.println("Song Playing------ ");
                                                j.previous().showSong();
                                            }
                                            else{
                                                System.out.println("Playlist finished.....");
                                                finished=true;
                                            }
                                            break;
                                        case 3:
                                            if(forward)
                                            {System.out.println("Current Song again\n\n");
                                                    j.previous().showSong();
                                                forward=false;
                                            }
                                            if(!forward)
                                            { System.out.println("Current Song again\n\n");
                                                    j.next().showSong();
                                                forward=true;
                                            }
                                            break;
                                        case 4:second=false;
                                            break;
                                        default:second=false;
                                            break;
                                    }
                                }
                            }
                            break;
                        case 5:first=false;
                            break;
                        default:first=false;
                            break;
                    }
                }
            }
        }



